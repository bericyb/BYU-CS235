
#pragma once
// #include <cstddef>
#include "NodeInterface.h"
#include "Node.h"
#include "AVLInterface.h"
#include <iostream>

using namespace std;

class AVL : public AVLInterface
{
protected:
	Node *root = NULL;
	bool increase;

public:
	AVL() {}
	virtual ~AVL()
	{
		clear();
	}

	//Please note that the class that implements this interface must be made
	//of objects which implement the NodeInterface

	/*
	* Returns the root node for this tree
	*
	* @return the root node for this tree.
	*/
	NodeInterface *getRootNode();

	/*
	* Attempts to add the given int to the AVL tree
	* Rebalances the tree if data is successfully added
	*
	* @return true if added
	* @return false if unsuccessful (i.e. the int is already in tree)
	*/
	bool add(int data);

	/*
	*Recursive function to add a new value to the tree. 
	*AVL Impletation is not done yet*
	*/
	bool rAdd(Node *&node, int data);

	/*
	* Attempts to remove the given int from the AVL tree
	* Rebalances the tree if data is successfully removed
	*
	
	* @return true if successfully removed
	* @return false if remove is unsuccessful(i.e. the int is not in the tree)
	*/
	bool remove(int data);


	/* Recursive function to help remove node from tree.


	*/
	bool rRemove(Node*& node, int data);

	/* Simple switcher function that works with the remove and recursive remove function.

	*/
	void replaceParent(Node *&old, Node *& fresh);

	/*
	* Removes all nodes from the tree, resulting in an empty tree.
	*/
	void clear();

	void deleteTree(Node *& node);

	/* Recalculates the height of a node in the tree and sets them.

	*/
	int calcHeight(Node *& node);

	void heightHelper();

	void printNodes(Node *node);

	void print();

	void rebalance(Node *& node);

	void rebalanceRightCheck(Node *& node);
	void rebalanceLeftCheck(Node *& node);
	void rightRotation(Node *& node);
	void leftRotation(Node* & node);
};
