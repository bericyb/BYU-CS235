#include "AVL.h"
#include "Node.h"

//Please note that the class that implements this interface must be made
//of objects which implement the NodeInterface

/*
	* Returns the root node for this tree
	*
	* @return the root node for this tree.
	*/
NodeInterface *AVL::getRootNode()
{
	if (root == NULL)
	{
		return NULL;
	}
	else
	{
		return root;
	}
}
/* Just interates and prints all of the nodes in the tree for the sake of my sanity...
also happens to set the height of all the nodes so that's handy. 
*/
void AVL::print()
{
	// heightHelper();
	printNodes(root);
}
void AVL::printNodes(Node *node)
{
	int left;
	int right;
	if (node->leftChild == NULL && node->rightChild == NULL)
	{
		// cout << "Reached a leaf!" << endl;
		// cout << "Data: " << node->data << "Height of node: " << calcHeight(node) << endl;
		return;
	}
	else
	{
		if (node->leftChild != NULL)
		{
			printNodes(node->leftChild);
			// //cout << "Data: " << node->data << "Height of node: " << calcHeight(node) << endl;
		}
		if (node->rightChild != NULL)
		{
			printNodes(node->rightChild);
			// //cout << "Data: " << node->data << "Height of node: " << calcHeight(node) << endl;
		}
	}
}

/* Recalculates the height of all nodes in the tree and the sets them.

*/
int AVL::calcHeight(Node *&node)
{
	if (node == NULL)
	{
		return -1;
	}
	else
	{
		int holder;
		holder = max(calcHeight(node->leftChild), calcHeight(node->rightChild)) + 1;
		node->height = holder;
		return holder;
	}
}

/*
	* Attempts to add the given int to the AVL tree
	* Rebalances the tree if data is successfully added
	*
	* @return true if added
	* @return false if unsuccessful (i.e. the int is already in tree)
	*/
bool AVL::add(int data)
{
	//cout << "Adding a new value! " << data << endl;
	if (root == NULL)
	{
		root = new Node(data);

		// //cout << "This is the height of the new node! " << endl
		//  << "Left: " << root->height << " Right: " << root->height << endl;
		return true;
	}
	else if (root->data > data)
	{
		increase = rAdd(root->leftChild, data);
		if (increase)
		{
			rebalance(root);
		}
		return increase;
	}
	else if (root->data < data)
	{
		increase = rAdd(root->rightChild, data);
		if (increase)
		{
			rebalance(root);
		}
		return increase;
	}
	else
	{
		//cout << "Adding failed: Value is same as root node." << endl;
		return false;
	}
}

/*
	*Recursive function to add a new value to the tree. 
	*AVL Impletation is not done yet*
	*/

bool AVL::rAdd(Node *&node, int data)
{
	// //cout << "In recursive add function" << endl;
	if (node == NULL)
	{
		node = new Node(data);
		increase = true;
		//cout << "Creating new node! " << endl;
		return increase;
	}
	else if (node->data > data)
	{
		rAdd(node->leftChild, data);
		//cout << "Just added a node!" << endl;
		if (increase)
		{
			rebalance(node);
			rebalance(node->leftChild);
			rebalance(node->rightChild);
		}
		return increase;
	}
	else if (node->data < data)
	{
		rAdd(node->rightChild, data);
		//cout << "Just added a node!" << endl;
		if (increase)
		{
			rebalance(node);
			rebalance(node->leftChild);
			rebalance(node->rightChild);
		}
		return increase;
	}
	else
	{
		//cout << "Adding failed" << endl;
		return false;
	}
}

/*
	* Attempts to remove the given int from the AVL tree
	* Rebalances the tree if data is successfully removed
	*
	* @return true if successfully removed
	* @return false if remove is unsuccessful(i.e. the int is not in the tree)
	* Removes all nodes from the tree, resulting in an empty tree.
	*/
bool AVL::remove(int data)
{
	//cout << "Removing a node : " << data << endl;
	bool getIt;
	getIt = rRemove(root, data);
	return getIt;
}

bool AVL::rRemove(Node *&node, int data)
{
	if (node == NULL)
	{
		increase = false;
		return increase;
	}
	else if (node->data > data)
	{
		rRemove(node->leftChild, data);
		if (increase)
		{
			rebalance(node);
		}
		return increase;
	}
	else if (node->data < data)
	{
		rRemove(node->rightChild, data);
		if (increase)
		{
			rebalance(node);
		}
		return increase;
	}
	else if (node->data == data)
	{
		Node *temp;
		temp = node;
		if (node->leftChild == NULL)
		{
			node = node->rightChild;
		}
		else if (node->rightChild == NULL)
		{
			node = node->leftChild;
		}
		else
		{
			replaceParent(temp, temp->leftChild);
			rebalance(node->leftChild);
			rebalance(node->rightChild);
			rebalance(node);
		}
		delete (temp);
		increase = true;
		// //cout<< "Success" << endl;
		return true;
	}
	else
	{
		// //cout<< "Not found!" << endl;
		return false;
	}
}

void AVL::replaceParent(Node *&old, Node *&fresh)
{
	if (fresh->rightChild != NULL)
	{
		replaceParent(old, fresh->rightChild);
		rebalance(fresh);
	}
	else
	{
		old->data = fresh->data;
		old = fresh;
		fresh = fresh->leftChild;
		return;
	}
}

/*
	*/
void AVL::clear()
{
	// //cout<< "In clear!" << endl;
	if (root == NULL)
	{
		// //cout<< "empty tree!" << endl;
		return;
	}
	/* //cout<< "Starting recursion" << endl;
	if (root->rightChild != NULL || root->leftChild != NULL)
	{
		deleteTree(root);
	}
	*/
	deleteTree(root);
	root = NULL;
}

void AVL::deleteTree(Node *&node)
{
	// //cout<< "In delete tree" << endl;
	if (node == NULL)
	{
		return;
	}

	deleteTree(node->rightChild);
	deleteTree(node->leftChild);

	delete (node);
	node = NULL;
	// //cout<< "Node deleted!" << endl;
	return;
}

void AVL::rebalance(Node *& node)
{
	if (node == NULL)
	{
		return;
	}
	//cout << "In rebalance: " << endl;
	//cout << "Checking this node! :" << node->data << endl;
	//cout << calcHeight(node->rightChild) << " left: " << calcHeight(node->leftChild) << endl;
	int balance = calcHeight(node->rightChild) - calcHeight(node->leftChild);
	//cout << "Here is the balance! " << balance << endl;
	if (balance < -1)
	{
		//cout << "Balancing the left side" << endl;
		// Balance the left side
		rebalanceLeftCheck(node->leftChild);
		rightRotation(node);
		return;
	}
	else if (balance > 1)
	{
		//cout << "Balancing the right side" << endl;
		// Balance the right side
		rebalanceRightCheck(node->rightChild);
		leftRotation(node);
	}
	else
	{
		//cout << "No rotation needed!" << endl;
		return;
	}
}
void AVL::rebalanceLeftCheck(Node *&node)
{
	// Check what kind of unbalance
	//cout << "Checking for Left-Right Rotation" << endl;
	if (calcHeight(node->rightChild) > calcHeight(node->leftChild))
	{
		// We have a right heavy imbalance in the left subtree! Requires Left-Right Rotation.

		// Left-Right rotation code
		//cout << "doing left right rotation!" << endl;
		leftRotation(node); //Changed from node->leftChild to node.
		return;
	}
	else
	{
		return;
	}
}

void AVL::rebalanceRightCheck(Node *&node)
{
	// Check what kind of unbalance
	//cout << "Checking for Right-Left Rotation" << endl;
	if (calcHeight(node->leftChild) > calcHeight(node->rightChild))
	{
		// We have a left heavy imbalance in the right subtree! Requires Right-Left Rotation

		// Right-Left Rotation code
		//cout << "Doing right left rotation" << endl;
		rightRotation(node); //Changed from node->rightChild to node.
		return;
	}
	else
	{
		return;
	}
}

void AVL::rightRotation(Node *&node)
{
	//cout << "In right Rotation!!!" << endl;
	Node *temp = node->leftChild;
	node->leftChild = temp->rightChild;
	temp->rightChild = node;
	node = temp;
}

void AVL::leftRotation(Node *&node)
{
	//cout << "In left Rotation!!!" << endl;
	Node *temp = node->rightChild;
	node->rightChild = temp->leftChild;
	temp->leftChild = node;
	node = temp;
}
