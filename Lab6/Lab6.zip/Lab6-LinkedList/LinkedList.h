#pragma once
#include "LinkedListInterface.h"
#include <sstream>
#include <string>
#include <iostream>
#include <stdexcept>
template <class T>
class LinkedList: public LinkedListInterface<T> {
    private:
		struct Node {
			T data;
			Node* next;
			Node(const T& the_data, Node* next_val = NULL) :
				data(the_data) {next = next_val;}
		};

		Node *mylist;
		int num_items;
		// string out_of_range = "Out of range bby";
    public:

        LinkedList(void) {
			mylist = NULL;
			num_items = 0;
		};
        virtual ~LinkedList() {};



        /*
	insertHead

	A node with the given value should be inserted at the beginning of the list.

	Do not allow duplicate values in the list.
	*/
	void insertHead(T value) {
		Node *temp;
		temp = mylist;
		// cout << value << "This is the value being passed through..."<< endl;
		for(Node *ptr =mylist; ptr != NULL; ptr = ptr->next)
		{
			//cout << "This is the temp->data value " << temp->data << endl;
			if(ptr->data == value) {
				// cout << "Duplicate found...at inserting at head..." << endl;
				return;
			}
		}
		Node *ptr = mylist;
		mylist = new Node(value);
		mylist->next = ptr;
		num_items++;
		// cout << "In insertHead" << endl;
	};

	/*
	insertTail
	A node with the given value should be inserted at the end of the list.

	Do not allow duplicate values in the list.
	*/
	void insertTail(T value){
		// cout << "In insertTail and inserting value : " << value << endl;
		Node *temp;
		temp = mylist;
		for(Node *ptr =mylist; ptr != NULL; ptr = ptr->next){
			// cout << "Looking number 1111!" << endl;
			cout << ptr->data << endl;
			if (ptr->data == value) {
				// cout << "Looking in for if... " << endl;
				return;
			}
		}
		while (temp != NULL && temp->next != NULL)
		{
			// cout << "looking for dups.. " << endl;
			if(temp->data == value) {
				// cout << "Duplicate found... for inserting at tail..." << endl;
				return;
			}
			temp = temp->next;
		}
		// cout << "Before" << endl;
		if  (temp == NULL) {insertHead(value);return;}
		temp->next = new Node(value);
		// cout << "After" << endl;
		num_items++;

	};

	/*
	insertAfter

	A node with the given value should be inserted immediately after the
	node whose value is equal to insertionNode.

	A node should only be added if the node whose value is equal to
	insertionNode is in the list. Do not allow duplicate values in the list.
	*/

	void insertAfter(T value, T insertionNode){
		// cout << "In insertafter! " << endl;
		Node *cur;
		Node *temp;
		Node* plusone;
		if (value == insertionNode) {return;}
        for(Node *ptr =mylist; ptr != NULL; ptr = ptr->next)
		{
            if(ptr->data == value) {return;}
        }
		for(Node *ptr =mylist; ptr != NULL; ptr = ptr->next)
		{
			// cout << "This is the temp->data value " << temp->data << endl;
			cur = ptr;
		// cout << "test" << endl;
			plusone = cur->next;
			if (cur->data == value) {return;}
			if(cur->data == insertionNode) {
				// cout << "Value found! Starting insertion!" << endl;
				temp = new Node(value);
				num_items++;
				cur->next = temp;
				temp->next = plusone;

				return;
			}
		}
	};

	/*
	remove

	The node with the given value should be removed from the list.

	The list may or may not include a node with the given value.
	*/
	void remove(T value){
		Node *prev;
		Node *cur;
		Node *after;
		Node* headHolder;
		// cout << "In Remove func... " << value << endl;
		// If node to be erased is head....
		if (num_items == 0) {return;}
		if (mylist->data == value) {
			headHolder = mylist;
			mylist = mylist->next;

			delete headHolder;
			num_items--;
		}
		for(Node *ptr =mylist; ptr != NULL; ptr = ptr->next)
		{
			prev = ptr;
			// cout << "Well nothing was deleted..." << endl;
			if (prev->next == NULL) {
				// cout << "Well this is the end of the line boiz..." << endl;
				// cout << prev->data << " Here's the data..." << endl;
				if (prev->data == value) {
					prev->next = NULL;
					delete ptr;
					num_items--;
				}
				return;
			}
			cur = ptr->next;
			// cout << "Setting up for a crash/..." << ptr->data << endl;
			// if (cur->next == NULL)
			// cout << "This is the temp->data value " << temp->data << endl;
			if(cur->data == value) {
				// cout << "Removal Found... Remove..." << endl;
				 // Setting the next of the previous node to the next next node. HMMMMMM
				after = cur->next;
				prev->next = after;
				delete cur;
				num_items--;
				return;
			}
		}
	};

	/*
	clear

	Remove all nodes from the list.
	*/
	void clear(){
		// cout << "In clear all function" << endl;
		Node *temp;
		while(mylist != NULL)
		{
			temp = mylist;
			mylist = mylist->next;
			delete temp;
			num_items = 0;
		}
	};

	/*
	at

	Returns the value of the node at the given index. The list begins at
	index 0.

	If the given index is out of range of the list, throw an out of range exception.
	*/
	T at(int index){
		// cout << "IN the at function " << endl;
		// cout << "Looking for index " << index << endl;
		int counter = 0;

		try {
			if (num_items == 0 || index < 0 || index > size()-1){throw std::out_of_range ("bleh");}
		}
		catch (string error) {
			cout << "Error: " << error << endl;
		}
		for(Node *ptr =mylist; ptr != NULL; ptr = ptr->next)
		{
			if (counter == index) {
				// cout << "found the index... printing value... " << ptr->data << endl;
				return (ptr->data);
			}
			counter++;
		}
		try {
			if (index > counter || index < 0) {throw std::out_of_range ("blah");}
		}
		catch (string error) {
			cout << "Error: " << error << endl;
		}
	};


	/*
	size

	Returns the number of nodes in the list.
	*/
	int size(){
		// cout << "Calling size function" << endl;
		return num_items;

	};

	/*
	toString

	Returns a string representation of the list, with the value of each node listed in order (Starting from the head) and separated by a single space
	There should be no trailing space at the end of the string

	For example, a LinkedList containing the value 1, 2, 3, 4, and 5 should return
	"1 2 3 4 5"
	*/
	string toString(){
		stringstream ss;
        string str;
		for(Node *ptr =mylist; ptr != NULL; ptr = ptr->next){
			ss <<ptr->data<<" ";
		}
		// cout <<"Printing the strings..." << ss.str() << endl;
            str = ss.str();
            if (!str.empty()){str.pop_back();}
            return (str);
	};




};
