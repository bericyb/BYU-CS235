#include "BST.h"
#include "Node.h"
#include <vector>
/*
	* Returns the root node for this tree
	*
	* @return the root node for this tree.
	*/
NodeInterface *BST::getRootNode() const
{
	// cout<< "getRootNode" << endl;
	if (root == NULL)
	{
		// cout<< "There is no ROOT!!!" << endl;
		return 0;
	}
	// cout<< "Here's the root! " << root->data << endl;
	return (root);
}

/*
	* Attempts to add the given int to the BST tree
	*
	* @return true if added
	* @return false if unsuccessful (i.e. the int is already in tree)
	*/
bool BST::add(int data)
{
	// Book code!
	/*// cout<< "add"<<endl;
	    Node *ptr = new Node(data);
	    ptr->leftChild = NULL; // To test that the friend relationship works
	    NodeInterface *rval = ptr->getLeftChild();
	    long value = (long)rval;
	    // cout<< "Added "<<value<<endl;
	    root = ptr;
		*/

	// My code...
	// cout<< "In add" << endl;
	if (root == NULL)
	{
		// cout<< "Adding in " << data << " as root!" << endl;
		root = new Node(data);
		return true;
	}
	else if (data > root->data)
	{
		rAdd(root->rightChild, data, root, 2);
	}
	else if (data < root->data)
	{
		rAdd(root->leftChild, data, root, 1);
	}
	else
	{
		// cout<< "outta there" << endl;
		return false;
	}
}

/* Recursive helper function! 


	*/
bool BST::rAdd(Node *&node, int data, Node *&prev, int dir)
{
	if (node == NULL)
	{
		// cout<< "base case found... inserting node" << endl;
		node = new Node(data);
		if (dir == 1)
		{
			prev->leftChild = node;
		}
		if (dir == 2)
		{
			prev->rightChild = node;
		}
		return true;
	}
	else if (data > node->data)
	{
		// cout<< "In right child" << endl;
		rAdd(node->rightChild, data, node, 2);
	}
	else if (data < node->data)
	{
		// cout<< "In left child" << endl;
		rAdd(node->leftChild, data, node, 1);
	}
	else
	{
		// cout<< "not added... MAYBE DUPLICATE" << endl;
		return false;
	}
}

/*
	* Attempts to remove the given int from the BST tree
	*
	* @return true if successfully removed
	* @return false if remove is unsuccessful(i.e. the int is not in the tree)
	*/
bool BST::remove(int data)
{
	// cout<< "remove" << endl;
	rRemove(root, data, root);
	/*
	Node *replacer;
	if (root == NULL)
	{
		return false;
	}
	if (root->data == data) {
		delete root;
		root = NULL;
	}
	else if (root->data == data)
	{
		replacer = removeFinder(root, root->leftChild, root->rightChild, data);
		root->data = replacer->data;
		// cout<< "Successfully removed " << data << " from the binary tree... Root removal" << endl;
	}
	else if (root->data > data)
	{
		rRemove(root->leftChild, data, root);
	}
	else if (root->data < data)
	{
		rRemove(root->rightChild, data, root);
	}
	*/
}

/*Recursive removal helper function!

	*/

bool BST::rRemove(Node *&node, int data, Node *prev)
{
	
	if (node == NULL)
	{
		return false;
	}
	else if (node->data > data)
	{
		rRemove(node->leftChild, data, node);
	}
	else if (node->data < data)
	{
		rRemove(node->rightChild, data, node);
	}
	else if (node->data == data)
	{
		Node *temp;
		temp = node;
		if (node->leftChild == NULL) {
			node = node->rightChild;
		} 
		else if (node->rightChild == NULL) {
			node = node->leftChild;
		}
		else {
			replaceParent(temp, temp->leftChild);
		}
		delete temp;
		// cout<< "Success" << endl;
		return true; 
		
		
		
		
		
		/*// IF THE NODE TO BE DELETED IS A LEAF
		if (node->leftChild == NULL && node->rightChild == NULL)
		{
			if (prev->data > node->data)
			{
				delete node;
				prev->leftChild = NULL;
				// cout<< "Successfully removed " << data << " from the binary tree... Leaf removal 1" << endl;
				return true;
			}
			else if (prev->data < node->data)
			{
				delete node;
				prev->rightChild = NULL;
				// cout<< "Successfully removed " << data << " from the binary tree...Leaf removal 2" << endl;
				return true;
			}
		}
		// IF THE NODE IS NOT A LEAF
		replacer = removeFinder(node, node->leftChild, node->rightChild, data);
		if (replacer == node->rightChild || replacer == node->leftChild)
		{
			if (node->leftChild == NULL)
			{
				Node* temp = node->rightChild;
				prev->leftChild = temp;
				// cout<< "Successfully removed" << endl;
				delete node;
				return true;
			}
			else if (node->rightChild == NULL)
			{
				Node* temp = node->leftChild;
				prev->rightChild = temp;
				// cout<< "Successfully removed" << endl;
				delete node;
				return true;
			}
		}
		node->data = replacer->data;
		// cout<< "Successfully removed " << data << " from the binary tree... Removal after traversal" << endl;
		return true;
		*/
	}
	else
	{
		// cout<< "Not found!" << endl;
		return false;
	}
}


void BST::replaceParent(Node* &old, Node* &fresh) {
			if (fresh->rightChild != NULL) {
				replaceParent(old, fresh->rightChild);
			}
			else {
				old->data = fresh->data;
				old = fresh;
				fresh = fresh->leftChild;
			}
		}

Node *BST::removeFinder(Node *&node, Node *&left, Node *&right, int data)
{
	if (left != NULL)
	{
		return (traverse(left, data, 2, node));
	}
	else if (right != NULL)
	{
		return (traverse(right, data, 1, node));
	}
}
/* Function to traverse the tree recursively. 
	1 is left and 2 is right for the dir integer...
	*/

Node *BST::traverse(Node *&node, int data, int dir, Node *&prev)
{
	// cout<< "In traverse" << endl;
	Node *temp;
	if (dir == 2)
	{
		if (node->rightChild == NULL)
		{
			temp = node;
			if (prev->data != data)
			{
				prev->rightChild = NULL;
			}
			else if (prev->data == data)
			{
				prev->leftChild = NULL;
			}
			delete node;
			checker = prev;
			return (temp);
		}
		else
		{
			traverse(node->rightChild, data, 2, node);
		}
	}
	if (dir == 1)
	{
		if (node->leftChild == NULL)
		{
			temp = node;
			if (prev->data != data)
			{
				prev->leftChild = NULL;
			}
			else if (prev->data == data)
			{
				prev->rightChild = NULL;
			}
			// prev->leftChild = NULL;
			delete node;
			checker = prev;
			return (temp);
		}
		else
		{
			traverse(node->leftChild, data, 1, node);
		}
	}
}

void BST::clear()
{
	// cout<< "In clear!" << endl;
	if (root == NULL)
	{
		// cout<< "empty tree!" << endl;
		return;
	}
	// cout<< "Starting recursion" << endl;
	if (root->rightChild != NULL|| root->leftChild != NULL) {
		deleteTree(root);
	}
	root = NULL;
}

void BST::deleteTree(Node *&node)
{
	// cout<< "In delete tree" << endl;
	if (node == NULL)
	{
		return;
	}

	deleteTree(node->rightChild);
	deleteTree(node->leftChild);

	delete (node);
	// cout<< "Node deleted!" << endl;
	return;
}

/*
	* Removes all nodes from the tree, resulting in an empty tree.
void BST::clear()
{
	// cout<< "clear" << endl;
	if (root == NULL)
	{
		// cout<< "The tree is empty!" << endl;
		return;
	}
	else if (root->rightChild != NULL)
	{
		rClear(root->rightChild, root, 2);
	}
	else if (root->leftChild != NULL)
	{
		rClear(root->leftChild, root, 1);
	}
}

Node *BST::rClear(Node *node, Node *prev, int dir)
{
	if (node->rightChild == NULL && node->leftChild == NULL)
	{
		if (dir == 1)
		{
			prev->leftChild = NULL;
		}
		if (dir == 2)
		{
			prev->rightChild = NULL;
		}
		delete node;
		return (node);
	}
	if (node->rightChild != NULL)
	{
		if (rClear(node->rightChild, node, 2)) {
			prev->rightChild = NULL;
			delete node;
		}
	}
	if (node->leftChild != NULL)
	{
		if (rClear(node->leftChild, node, 1)) {
			prev->leftChild = NULL;
			delete node;
		}
	}

	// cout<< "The tree is empty" << endl;
}
	*/
